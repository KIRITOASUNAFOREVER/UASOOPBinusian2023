import java.util.Date;

public class Administrator extends Karyawan{
	private String titleStatus;


	@Override
	public String toString() {
		return "Administrator [titleStatus=" + titleStatus + ", getTitleStatus()=" + getTitleStatus()+"\n" + ", toString()="
				+ super.toString() + ", getOfficeLocation()=" + getOfficeLocation()+"\n" + ", getSalary()=" + getSalary()+"\n"
				+ ", getMulaiKerja()=" + getMulaiKerja()+"\n" + ", getName()=" + getName()+"\n" + ", getAddress()=" + getAddress()+"\n"
				+ ", getPhoneNumber()=" + getPhoneNumber() +"\n"+ ", getEmail()=" + getEmail()+"\n" + ", getClass()=" + getClass()+"\n"
				+ ", hashCode()=" + hashCode() + "]";
	}

	

	public Administrator(String name, String address, String phoneNumber, String email, String officeLocation,
			int salary, Date mulaiKerja, String titleStatus) {
		super(name, address, phoneNumber, email, officeLocation, salary, mulaiKerja);
		this.titleStatus = titleStatus;
	}



	public String getTitleStatus() {
		return titleStatus;
	}

	public void setTitleStatus(String titleStatus) {
		this.titleStatus = titleStatus;
	}
	
}
