import java.util.Calendar;
import java.util.Date;

public class Dosen extends Karyawan{
	private int teachingHours;
	private String academicLevel;
	
	@Override
	public String toString() {
		return "Dosen [teachingHours=" + teachingHours + ", academicLevel=" + academicLevel + ", getTeachingHours()="
				+ getTeachingHours()+"\n" + ", getAcademicLevel()=" + getAcademicLevel()+"\n" + ", toString()=" + super.toString()
				+ ", getOfficeLocation()=" + getOfficeLocation()+"\n" + ", getSalary()=" + getSalary()+"\n" + ", getMulaiKerja()="
				+ getMulaiKerja() +"\n"+ ", getName()=" + getName()+"\n" + ", getAddress()=" + getAddress()+"\n"
				+ ", getPhoneNumber()=" + getPhoneNumber()+"\n" + ", getEmail()=" + getEmail() +"\n"+ ", getClass()=" + getClass()+"\n"
				+ ", hashCode()=" + hashCode() + "]";
	}



	public Dosen(String name, String address, String phoneNumber, String email, String officeLocation, int salary,
			Date mulaiKerja, int teachingHours, String academicLevel) {
		super(name, address, phoneNumber, email, officeLocation, salary, mulaiKerja);
		this.teachingHours = teachingHours;
		this.academicLevel = academicLevel;
	}



	public int getTeachingHours() {
		return teachingHours;
	}

	public void setTeachingHours(int teachingHours) {
		this.teachingHours = teachingHours;
	}

	public String getAcademicLevel() {
		return academicLevel;
	}

	public void setAcademicLevel(String academicLevel) {
		this.academicLevel = academicLevel;
	}
}
