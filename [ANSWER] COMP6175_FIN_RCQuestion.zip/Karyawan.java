import java.util.Date;

public class Karyawan extends Orang{
	private String officeLocation;
	private int salary;
	private Date mulaiKerja;
	
	
	
	@Override
	public String toString() {
		return "Karyawan [officeLocation=" + officeLocation + ", salary=" + salary + ", mulaiKerja=" + mulaiKerja
				+ ", getOfficeLocation()=" + getOfficeLocation() + ", getSalary()=" + getSalary() + ", toString()="
				+ super.toString() + ", getName()=" + getName() + ", getAddress()=" + getAddress()
				+ ", getPhoneNumber()=" + getPhoneNumber() + ", getEmail()=" + getEmail() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}

	

	public Karyawan(String name, String address, String phoneNumber, String email, String officeLocation, int salary,
			Date mulaiKerja) {
		super(name, address, phoneNumber, email);
		this.officeLocation = officeLocation;
		this.salary = salary;
		this.mulaiKerja = mulaiKerja;
	}



	public String getOfficeLocation() {
		return officeLocation;
	}

	public void setOfficeLocation(String officeLocation) {
		this.officeLocation = officeLocation;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public Date getMulaiKerja() {
		return mulaiKerja;
	}

	public void setMulaiKerja(Date mulaiKerja) {
		this.mulaiKerja = mulaiKerja;
	}
}
