
public class Mahasiswa extends Orang{
	private int yearOfTheStudent;

	@Override
	public String toString() {
		return "Mahasiswa [yearOfTheStudent=" + yearOfTheStudent + ", getYearOfTheStudent()=" + getYearOfTheStudent()+"\n"
				+ ", toString()=" + super.toString() + ", getName()=" + getName()+"\n" + ", getAddress()=" + getAddress()+"\n"
				+ ", getPhoneNumber()=" + getPhoneNumber()+"\n" + ", getEmail()=" + getEmail() +"\n"+ ", getClass()=" + getClass()+"\n"
				+ ", hashCode()=" + hashCode() + "]";
	}

	public Mahasiswa(String name, String address, String phoneNumber, String email, int yearOfTheStudent) {
		super(name, address, phoneNumber, email);
		this.yearOfTheStudent = yearOfTheStudent;
	}

	public int getYearOfTheStudent() {
		return yearOfTheStudent;
	}

	public void setYearOfTheStudent(int yearOfTheStudent) {
		this.yearOfTheStudent = yearOfTheStudent;
	}
}
