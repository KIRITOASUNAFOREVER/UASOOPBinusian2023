import java.util.*;

public class Main {
	Scanner scan  = new Scanner(System.in);
	Vector<Mahasiswa> ListMahasiswa = new Vector<>();
	Vector<Dosen> ListDosen = new Vector<>();
	Vector<Administrator> ListAdministrator = new Vector<>();
	
	void LoginAdministrator(){
		int pilihanMenuAdministrator;
		String tempNama;
		String tempAlamat;
		String tempNomorTelepon;
		String tempEmail;
		int tempTahunMasuk;
		String tempLokasiKantor;
		int tempGaji;
		int tempLamaMengajar;
		String tempAcademicLevel;
		String tempTitleStatus;
		int jumlahMahasiswa;
		int jumlahDosen;
		int jumlahAdministrator;
		
		do{
			System.out.println("1. Profile");
			System.out.println("2. Add Mahasiswa");
			System.out.println("3. Add Dosen");
			System.out.println("4. Add Administrator");
			System.out.println("5. List All Mahasiswa");
			System.out.println("6. List All Dosen");
			System.out.println("7. List All Administrator");
			System.out.println("8. List All User");
			System.out.println("9  Change User");
			System.out.print("Masukkan Pilihan Anda : ");
			pilihanMenuAdministrator = scan.nextInt();scan.nextLine();
			
			switch(pilihanMenuAdministrator){
			case 1:
				System.out.println();System.out.println();
				System.out.println("1) Nama Administrator");
				System.out.println("2) Nomor Telepon");
				System.out.println("3) Lokasi Kantor");
				System.out.println("4) Email");
				System.out.println("5) Title Status");
				System.out.println("6) Salary");
				System.out.println("7) Date When They Working");
				System.out.println("Press Enter to Continue....");
				scan.nextLine();
				break;
			case 2:
				System.out.println();System.out.println();
				
				System.out.print("Masukkan Nama Anda : ");
				tempNama = scan.nextLine();
				
				System.out.print("Masukkan Alamat Rumah Anda : ");
				tempAlamat = scan.nextLine();
				
				System.out.print("Masukkan Nomor Telepon Anda : ");
				tempNomorTelepon = scan.nextLine();
				
				System.out.print("Masukkan Email Anda : ");
				tempEmail = scan.nextLine();
				
				do{
					System.out.print("Masukkan Tahun Masuk Anda [2015 || 2016 || 2017 || 2017 || 2018 || 2019 || 2020]: ");
					tempTahunMasuk = scan.nextInt();scan.nextLine();
				}while(tempTahunMasuk != 2015 && tempTahunMasuk !=2016 && tempTahunMasuk !=2017 && tempTahunMasuk !=2018 && tempTahunMasuk !=2019 && tempTahunMasuk !=2020);
				ListMahasiswa.add(new Mahasiswa(tempNama, tempAlamat, tempNomorTelepon, tempEmail, tempTahunMasuk));
				System.out.println("Memproses Data Mahasiswa.........., Mohon Tunggu beberapa Detik");System.out.println();
				Thread Mahasiswa=new Thread(new Threading(5));
				Mahasiswa.run();
				System.out.println("Sukses Menambah Data Mahasiswa");
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 3:
				System.out.println();System.out.println();
				
				System.out.print("Masukkan Nama Anda : ");
				tempNama = scan.nextLine();
				
				System.out.print("Masukkan Alamat Rumah Anda : ");
				tempAlamat = scan.nextLine();
				
				System.out.print("Masukkan Nomor Telepon Anda : ");
				tempNomorTelepon = scan.nextLine();
				
				System.out.print("Masukkan Email Anda : ");
				tempEmail = scan.nextLine();
				
				do{
					System.out.print("Masukkan Lokasi Kantor Anda [Kemanggisan || Alam Sutra || Bekasi ||Bandung || Malang] : ");
					tempLokasiKantor = scan.nextLine();
				}while(!tempLokasiKantor.equals("Kemanggisan") && !tempLokasiKantor.equals("Alam Sutra") && !tempLokasiKantor.equals("Bekasi") && !tempLokasiKantor.equals("Bandung") && !tempLokasiKantor.equals("Malang"));
				
				System.out.print("Masukkan Jumlah Gaji Anda : ");
				tempGaji = scan.nextInt();scan.nextLine();
				
				System.out.println("Masukkan Jumlah Jam Mengajar (Dalam Jam) : ");
				tempLamaMengajar = scan.nextInt();scan.nextLine();
				
				do{
					System.out.println("Masukkan Level Akademik Anda [Asisten Ahli || Lektor || Lektor Kepala || Professor]: ");
					tempAcademicLevel = scan.nextLine();
				}while(!tempAcademicLevel.equals("Asisten Ahli") && !tempAcademicLevel.equals("Lektor") && !tempAcademicLevel.equals("Lektor Kepala") && !tempAcademicLevel.equals("Professor"));
				
				Calendar tempTanggal = Calendar.getInstance();
				
				ListDosen.add(new Dosen(tempNama, tempAlamat, tempNomorTelepon, tempEmail, tempLokasiKantor, tempGaji, (tempTanggal.getTime()), tempLamaMengajar, tempAcademicLevel));
				System.out.println("Memproses Data Dosen.........., Mohon Tunggu beberapa Detik");System.out.println();
				Thread Dosen=new Thread(new Threading(5));
				Dosen.run();
				System.out.println("Sukses Menambah Data Dosen");
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 4:
				System.out.println();System.out.println();
				
				System.out.print("Masukkan Nama Anda : ");
				tempNama = scan.nextLine();
				
				System.out.print("Masukkan Alamat Rumah Anda : ");
				tempAlamat = scan.nextLine();
				
				System.out.print("Masukkan Nomor Telepon Anda : ");
				tempNomorTelepon = scan.nextLine();
				
				System.out.print("Masukkan Email Anda : ");
				tempEmail = scan.nextLine();
				
				do{
					System.out.print("Masukkan Lokasi Kantor Anda [Kemanggisan || Alam Sutra || Bekasi ||Bandung || Malang] : ");
					tempLokasiKantor = scan.nextLine();
				}while(!tempLokasiKantor.equals("Kemanggisan") && !tempLokasiKantor.equals("Alam Sutra") && !tempLokasiKantor.equals("Bekasi") && !tempLokasiKantor.equals("Bandung") && !tempLokasiKantor.equals("Malang"));
				
				System.out.print("Masukkan Jumlah Gaji Anda : ");
				tempGaji = scan.nextInt();scan.nextLine();
				
				do{
					System.out.println("Masukkan Jabatan Anda [Staff || Supervisor || Manager || Kepala Divisi || Direksi]: ");
					tempTitleStatus = scan.nextLine();
				}while(!tempTitleStatus.equals("Staff") && !tempTitleStatus.equals("Supervisor") && !tempTitleStatus.equals("Manager") && !tempTitleStatus.equals("Kepala Divisi") && !tempTitleStatus.equals("Direksi"));
				
				Calendar tempTanggalAdmin = Calendar.getInstance();
				ListAdministrator.add(new Administrator(tempNama, tempNomorTelepon, tempLokasiKantor, tempEmail, tempLokasiKantor, tempGaji, (tempTanggalAdmin.getTime()), tempTitleStatus));
				System.out.println("Memproses Data Administrator.........., Mohon Tunggu beberapa Detik");System.out.println();
				Thread Administrator=new Thread(new Threading(5));
				Administrator.run();
				System.out.println("Sukses Menambah Data Administrator");
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 5:
				jumlahMahasiswa = ListMahasiswa.size();
				if(jumlahMahasiswa==0){
					System.out.println("Tidak Ada Data Mahasiswa");
					System.out.println("Press Enter to Continue...");
					scan.nextLine();
				}
				else{
					for(int i=0;i<ListMahasiswa.size();i++){
						System.out.printf("%d) Nama: %s\n",i+1,ListMahasiswa.get(i).getName());
						System.out.printf("   Tahun Masuk : %d\n",ListMahasiswa.get(i).getYearOfTheStudent());
						System.out.println();
					}
				}
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 6:
				jumlahDosen = ListDosen.size();
				if(jumlahDosen==0){
					System.out.println("Tidak Ada Data Dosen");
					System.out.println("Press Enter to Continue...");
					scan.nextLine();
				}
				else{
					for(int i=0;i<ListDosen.size();i++){
						System.out.printf("%d) Nama: %s\n",i+1,ListDosen.get(i).getName());
						System.out.printf("   Lokasi Kantor  : %s\n",ListDosen.get(i).getOfficeLocation());
						System.out.printf("   Level Akademik : %s\n",ListDosen.get(i).getAcademicLevel());
						System.out.println();
					}
				}
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 7:
				jumlahAdministrator = ListAdministrator.size();
				if(jumlahAdministrator==0){
					System.out.println("Tidak Ada Data Administrator");
					System.out.println("Press Enter to Continue...");
					scan.nextLine();
				}
				else{
					for(int i=0;i<ListAdministrator.size();i++){
						System.out.printf("%d) Nama: %s\n",i+1,ListAdministrator.get(i).getName());
						System.out.printf("   Lokasi Kantor  : %s\n",ListAdministrator.get(i).getOfficeLocation());
						System.out.printf("   Status Jabatan : %s\n",ListAdministrator.get(i).getTitleStatus());
						System.out.println();
					}
				}
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 8:
				System.out.println(ListMahasiswa.toString());
				System.out.println();
				System.out.println(ListDosen.toString());
				System.out.println();
				System.out.println(ListAdministrator.toString());
				break;
			}
		}while(pilihanMenuAdministrator < 1 || pilihanMenuAdministrator > 9 || pilihanMenuAdministrator !=9);
	}
	
	void LoginMahasiswa(){
		String namaMahasiswa;
		int penanda = 0;
		int indeks = 0;
		int totalMahasiswa;
		int pilihanMahasiswa;
		String tempAlamat;
		String tempEmail;
		String tempNomorTelepon;
		totalMahasiswa  = ListMahasiswa.size();
		
		if(totalMahasiswa==0){
			System.out.println("Tidak Ada Data Mahasiswa");
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
		}
		else{
			System.out.println("Masukkan Nama Anda : ");
			namaMahasiswa = scan.nextLine();
			
			for(int i=0;i<ListMahasiswa.size();i++)
			{
				if(namaMahasiswa.equals(ListMahasiswa.get(i).getName())){
					penanda = 1;
					indeks = i;
				}
				else
				{
					penanda = 0;
				}
			}
			System.out.println("Mencari Kecocokan Data.........., Mohon Tunggu beberapa Detik");System.out.println();
			Thread CariMahasiswa=new Thread(new Threading(5));
			CariMahasiswa.run();
			if(penanda==0){
				System.out.println("Data Dengan Nama Tersebut Tidak Ditemukan");
			}
			else if(penanda==1){
				do{
					System.out.println("1. Profile");
					System.out.println("2. Change address");
					System.out.println("3. Change phone number");
					System.out.println("4. Change email");
					System.out.println("5. Change user");
					System.out.println("Masukkan Pilihan Anda : ");
					pilihanMahasiswa= scan.nextInt();scan.nextLine();
					
					switch(pilihanMahasiswa){
					case 1:
						System.out.println();System.out.println();
						System.out.println("1) Nama Mahasiswa : "+ListMahasiswa.get(indeks).getName());
						System.out.println("2) Alamat : "+ListMahasiswa.get(indeks).getAddress());
						System.out.println("3) Nomor Telepon : "+ListMahasiswa.get(indeks).getPhoneNumber());
						System.out.println("4) Email : "+ListMahasiswa.get(indeks).getEmail());
						System.out.println("5) Tahun Masuk : "+ListMahasiswa.get(indeks).getYearOfTheStudent());
						System.out.println("Press Enter to Continue....");
						scan.nextLine();
						 break;
					case 2:
						System.out.print("Masukkan Alamat Rumah Anda : ");
						tempAlamat = scan.nextLine();
						
						ListMahasiswa.get(indeks).setAddress(tempAlamat);
						break;
					case 3:
						System.out.print("Masukkan Nomor Telepon Anda : ");
						tempNomorTelepon = scan.nextLine();
						
						ListMahasiswa.get(indeks).setPhoneNumber(tempNomorTelepon);
						break;
					case 4:
						System.out.print("Masukkan Email Anda : ");
						tempEmail = scan.nextLine();
						
						ListMahasiswa.get(indeks).setEmail(tempEmail);
						break;
					}
				}while(pilihanMahasiswa < 1 || pilihanMahasiswa > 5 || pilihanMahasiswa !=5);
			}
		}
	}
	
	void LoginDosen(){
		String namaDosen;
		int penanda = 0;
		int indeks = 0;
		int totalDosen;
		int pilihanDosen;
		String tempAlamat;
		String tempEmail;
		String tempNomorTelepon;
		totalDosen  = ListDosen.size();
		
		if(totalDosen==0){
			System.out.println("Tidak Ada Data Dosen");
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
		}
		else{
			System.out.println("Masukkan Nama Anda : ");
			namaDosen = scan.nextLine();
			
			for(int i=0;i<ListDosen.size();i++)
			{
				if(namaDosen.equals(ListDosen.get(i).getName())){
					penanda = 1;
					indeks = i;
				}
				else
				{
					penanda = 0;
				}
			}
			System.out.println("Mencari Kecocokan Data.........., Mohon Tunggu beberapa Detik");System.out.println();
			Thread CariDosen=new Thread(new Threading(5));
			CariDosen.run();
			if(penanda==0){
				System.out.println("Data Dengan Nama Tersebut Tidak Ditemukan");
			}
			else if(penanda==1){
				do{
					System.out.println("1. Profile");
					System.out.println("2. Change address");
					System.out.println("3. Change phone number");
					System.out.println("4. Change email");
					System.out.println("5. Change user");
					System.out.println("Masukkan Pilihan Anda : ");
					pilihanDosen= scan.nextInt();scan.nextLine();
					
					switch(pilihanDosen){
					case 1:
						System.out.println();System.out.println();
						System.out.println("1) Nama Dosen : "+ListDosen.get(indeks).getName());
						System.out.println("2) Alamat : "+ListDosen.get(indeks).getAddress());
						System.out.println("3) Nomor Telepon : "+ListDosen.get(indeks).getPhoneNumber());
						System.out.println("4) Email : "+ListDosen.get(indeks).getEmail());
						System.out.println("5) Lokasi Kantor : "+ListDosen.get(indeks).getOfficeLocation());
						System.out.println("6) Level Akademik : "+ListDosen.get(indeks).getAcademicLevel());
						System.out.println("7) Jumlah Jam Mengajar : "+ListDosen.get(indeks).getTeachingHours());
						System.out.println("8) Gaji Dosen : "+ListDosen.get(indeks).getSalary());
						System.out.println("9) Mulai Kerja : "+ListDosen.get(indeks).getMulaiKerja());
						System.out.println("Press Enter to Continue....");
						scan.nextLine();
						 break;
					case 2:
						System.out.print("Masukkan Alamat Rumah Anda : ");
						tempAlamat = scan.nextLine();
						
						ListDosen.get(indeks).setAddress(tempAlamat);
						break;
					case 3:
						System.out.print("Masukkan Nomor Telepon Anda : ");
						tempNomorTelepon = scan.nextLine();
						
						ListDosen.get(indeks).setPhoneNumber(tempNomorTelepon);
						break;
					case 4:
						System.out.print("Masukkan Email Anda : ");
						tempEmail = scan.nextLine();
						
						ListDosen.get(indeks).setEmail(tempEmail);
						break;
					}
				}while(pilihanDosen < 1 || pilihanDosen > 5 || pilihanDosen !=5);
			}
		}
	}
	
	public Main() {
		int pilihanAwal;
		
		do{
			System.out.println("XYZ University");
			System.out.println("==============");
			System.out.println("1. Login Sebagai Mahasiswa");
			System.out.println("2. Login Sebagai Dosen");
			System.out.println("3. Login Sebagai Administrator");
			System.out.println("4. Keluar dari Sistem");
			System.out.print("Masukkan Pilihan Anda : ");
			pilihanAwal = scan.nextInt();scan.nextLine();
			
			switch(pilihanAwal){
			case 1:
				LoginMahasiswa();
				break;
			case 2:
				LoginDosen();
				break;
			case 3:
				LoginAdministrator();
				break;
			}
		}while(pilihanAwal < 1 || pilihanAwal > 4 || pilihanAwal != 4);
		
	}

	public static void main(String[] args) {
		new Main();
	}
}