
public class Threading implements Runnable{
	Thread t;
	int WaktuTunggu;

	public Threading(int x) {
		t = new Thread(this);
		t.run();
		this.WaktuTunggu = x;
	}
	
	
	public void run() {
		while(WaktuTunggu!=0) {
			WaktuTunggu--;
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}